import pygame
import sys
import random
import math
import string

#Constants
width = 1096
height = 690
MAPFILE = "Scrabble Board.txt"
LETTERBAG = "Scrabble Letter Bag.txt"
DICTIONARY = "Collins Scrabble Words (2019).txt"
GOLD = (153, 153, 0)
BLUE = (55, 55, 255)
GREEN = (0, 200, 0)
RED = (255, 0, 0)
UGLY_PINK = (255, 0, 255)
DARKORANGE = (255, 128, 0)
BLACK = (0, 0, 0)
GREY = (96,96,96)
BLOCK_LENGTH = 42
GREEN_GO = (0,153,0)
current_player_indicator = (255, 60, 120)
pygame.init()
win = pygame.display.set_mode((width, height))
pygame.display.set_caption("Scrabble")
TW = []
DW = []
DL = []
TL = []

#Score Variables
player_one_name = ""
player_two_name = ""
player_score = 0
player_two_score = 0
turn_score = player_score
font = pygame.font.Font('freesansbold.ttf' , 32)

class Button():
    def __init__(self, color, x,y,width,height, text=''):
        self.color = color
        self.default_color = color
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text
        self.rect = pygame.Rect(x,y,width,height)

    def set_Color(self, color):
    	self.default_color = color

    def draw(self,win,outline=None):
        #Call this method to draw the button on the screen
        if outline:
            pygame.draw.rect(win, outline, (self.x-2,self.y-2,self.width+4,self.height+4),0)
            
        pygame.draw.rect(win, self.color, (self.x,self.y,self.width,self.height),0)
        
        if self.text != '':
            font = pygame.font.SysFont('comicsans', 60)
            text = font.render(self.text, 1, (0,0,0))
            win.blit(text, (self.x + (self.width/2 - text.get_width()/2), self.y + (self.height/2 - text.get_height()/2)))
    def update(self):
    	pos = pygame.mouse.get_pos()
    	if(self.rect.collidepoint(pos) and self.default_color != GOLD):
    		self.color = GREEN_GO
    	else:
    		self.color = self.default_color
class Indicator(pygame.sprite.Sprite):
	def __init__(self, pos_x,pos_y, image):
		pygame.sprite.Sprite.__init__(self)
		self.pos_x = pos_x
		self.pos_y = pos_y
		self.image = pygame.image.load(image)
		self.rect = self.image.get_rect()
		self.rect.center = [pos_x,pos_y]
	def draw(self, win):
		win.blit(self.image,self.rect)
	def MoveTo(self, x,y):
		self.pos_x = x
		self.pos_y = y
		self.rect.center = [self.pos_x, self.pos_y]
class Letter(pygame.sprite.Sprite):
	def __init__(self, pos_x, pos_y, letter, point_value, letter_image):
		pygame.sprite.Sprite.__init__(self)
		self.original_image = pygame.image.load(letter_image)
		self.image = self.original_image
		self.rect = self.image.get_rect()
		self.rect.center = [pos_x, pos_y]
		self.selected = False
		self.letter = letter
		self.original_letter = letter
		self.pos_x = pos_x
		self.pos_y = pos_y
		self.point_value = point_value
		self.coordinates = (15,15)
		self.to_be_exchanged = False
		self.angle = 0
	def Exchange(self):
		self.image = pygame.image.load("Exchange Letter.png")
	def Default_Image(self):
		self.image = self.original_image
	def Assign_Blank(self, assignment):
		self.letter = assignment
	def snap(self, coordinates, letters_on_board):
		snap_points = []
		current_snap_point = (0,0)
		for lockpoint in coordinates:
			if (math.dist(self.rect.center, ((lockpoint[0]*BLOCK_LENGTH+BLOCK_LENGTH/2), (lockpoint[1]*BLOCK_LENGTH+BLOCK_LENGTH/2)) ) <= BLOCK_LENGTH):
				snap_points.append(lockpoint)
				#print("Considering the Snap Point", lockpoint)
				current_snap_point = lockpoint
		for snap_point in snap_points:
			if (math.dist(self.rect.center, ((snap_point[0]*BLOCK_LENGTH+BLOCK_LENGTH/2), (snap_point[1]*BLOCK_LENGTH+BLOCK_LENGTH/2)) ) <= 
				(math.dist(self.rect.center, ((current_snap_point[0]*BLOCK_LENGTH+BLOCK_LENGTH/2), (current_snap_point[1]*BLOCK_LENGTH +BLOCK_LENGTH/2)) ))):
					current_snap_point = snap_point
					#print("Setting Snap Point to", current_snap_point)
		if(len(snap_points) > 0):
			safety_bot = self.rect.copy()
			clear = True
			safety_bot.x = ((current_snap_point[0]*BLOCK_LENGTH+BLOCK_LENGTH/2)) 
			safety_bot.y = ((current_snap_point[1]*BLOCK_LENGTH+BLOCK_LENGTH/2))
			for letter in letters_on_board:
				if(safety_bot.collidepoint(letter.rect.center) and letter != self):
					clear = False
			#print("Snapping to", current_snap_point)
			if(clear == True):
				self.rect.center = ((current_snap_point[0]*BLOCK_LENGTH+BLOCK_LENGTH/2, current_snap_point[1]*BLOCK_LENGTH+BLOCK_LENGTH/2))
				self.pos_x = self.rect.center[0]
				self.pos_y = self.rect.center[1]
				self.coordinates = (current_snap_point[0], current_snap_point[1])
				return True
		return False
	def get_rect(self):
		return self.rect
	def update(self):
		if(self.selected == True):
			self.rect.center = pygame.mouse.get_pos()
		
def show_score(name, score, x, y):
	score = font.render(name + ": " + str(score), True, RED)
	win.blit(score, (x, y))
def display_name_entry(name, x, y):
	display_name = font.render(name, True, BLUE)
	win.blit(display_name, (x, y))
def display_winner(winner, x, y):
	display_winner = font.render(winner + " WINS!", True, GOLD)
	win.blit(display_winner, (x, y))
def draw_blank_selection(surface, buttons):
	myrect = pygame.Rect(640, 20, 500, 630)
	pygame.draw.rect(surface, RED, myrect)
	for button in buttons:
		button.update()
		button.draw(win)
def create_blank_buttons():
	uppercase_alphabet = string.ascii_uppercase
	blank_buttons = []
	x_placement = 650
	y_placement = 0
	for i in range(0,26):
		if((i%3) == 0):
			x_placement = 650
			y_placement += 50
		elif((i%3) == 1):
			x_placement = 725
		elif((i%3) == 2):
			x_placement = 800
		blank_buttons.append(Button(GREY, x_placement, y_placement, BLOCK_LENGTH, BLOCK_LENGTH, uppercase_alphabet[i]))
	return blank_buttons
def redrawWindow(win, letter_rack_group, letter_group, game_buttons, blank_buttons, using_blank, indicator, reveal_button, show_reveal, mapfile):
	win.fill((0,0,0)) #Redrawing the Window involves filling in the black background, drawing the game board, and the current letters
	draw_map(win, mapfile)
	draw_grid(win)
	draw_letter_rack(win)
	show_score(player_one_name, player_score, 705, 75)
	show_score(player_two_name, player_two_score, 705, 125)
	letter_rack_group.update()
	letter_rack_group.draw(win)
	letter_group.update()
	letter_group.draw(win)
	indicator.draw(win)
	if(show_reveal == True):
		reveal_button.update()
		reveal_button.draw(win)
	if(using_blank == True):
		draw_blank_selection(win, blank_buttons)
	elif(using_blank == False):
		for button in game_buttons:
			button.update()
			button.draw(win)
	pygame.display.update()
	pygame.display.flip()

def redrawIntro(win, blank_buttons, confirm_button, delete_button, indicator, player_name_one, player_name_two):
	win.fill(BLACK)
	for button in blank_buttons:
		button.update()
		button.draw(win)
	confirm_button.update()
	confirm_button.draw(win)
	delete_button.update()
	delete_button.draw(win)
	indicator.draw(win)
	enter_your_names = font.render("Enter Your Names" + ": ", True, RED)
	win.blit(enter_your_names, (265, 40))
	display_name_entry(player_one_name, 150, 150)
	display_name_entry(player_two_name, 150, 300)
	pygame.display.update()
	pygame.display.flip()

def game_over_screen(win, letter_group, finish_button, end_game_points, winner, mapfile):
	win.fill((0,0,0)) #Redrawing the Window ,es filling in the black background, drawing the game board, and the current letters
	draw_map(win, mapfile)
	draw_grid(win)
	letter_group.update()
	letter_group.draw(win)
	finish_button.update()
	finish_button.draw(win)
	show_score(player_one_name, player_score, 705, 75)
	show_score(player_two_name, player_two_score, 705, 125)
	display_winner(winner, 705, 200)
	pygame.display.update()
	pygame.display.flip()


def get_tile_color(tile_contents):
    tile_color = GOLD
    if tile_contents == "Q":
        tile_color = DARKORANGE
    if tile_contents == "A":
        tile_color = GOLD
    if tile_contents == "B":
        tile_color = BLUE
    if tile_contents == "C":
        tile_color = GREEN
    if tile_contents == "S":
    	tile_color = UGLY_PINK
    if tile_contents == "P":
    	tile_color = RED
    return tile_color

def draw_grid(surface):
    for i in range(15):
        new_height = round(i * BLOCK_LENGTH)
        new_width = round(i * BLOCK_LENGTH)
        pygame.draw.line(surface, BLACK, (0, new_height), (width, new_height), 2)
        pygame.draw.line(surface, BLACK, (new_width, 0), (new_width, height), 2)

def draw_letter_rack(surface):
		#Draws a horizontal line
		pygame.draw.line(surface, UGLY_PINK, (675, BLOCK_LENGTH+600), (1018, BLOCK_LENGTH+600), 2)
		#Draws Vertical Lines
		for i in range(8):
			pygame.draw.line(surface,UGLY_PINK, (675 +(49*i), BLOCK_LENGTH+600), (675 + (49*i), BLOCK_LENGTH+566),2)

def draw_map(surface, map_tiles):
    for j, tile in enumerate(map_tiles):
        for i, tile_contents in enumerate(tile):
            myrect = pygame.Rect(i*BLOCK_LENGTH, j*BLOCK_LENGTH, BLOCK_LENGTH, BLOCK_LENGTH)
            pygame.draw.rect(surface, get_tile_color(tile_contents), myrect)

def detect_tile_type(letter):
	TW = [(0,0), (0,7), (0,14)]
def get_coordinates(map_tiles):
	coordinates = []
	global TW
	global DW
	global DL
	global TL
	#Mark all of the special tile coordinates
	for j, tile in enumerate(map_tiles):
		for i, tile_contents in enumerate(tile):
			coordinates.append((i,j))
			if (tile_contents == 'Q'):
				TW.append((i,j))
			if (tile_contents == 'B'):
				DL.append((i,j))
			if (tile_contents == 'P' or tile_contents == 'S'):
				DW.append((i,j))
			if (tile_contents == 'C'):
				TL.append((i,j))
	return coordinates

def read_map(mapfile):
    with open(mapfile, 'r') as f:
        world_map = f.readlines()
    world_map = [line.strip() for line in world_map]
    return (world_map)

def read_bag(mapfile):
    with open(mapfile, 'r') as f:
        world_map = f.read()
    world_map = [line.strip() for line in world_map]
    #Get rid of whitespace
    while ('' in world_map):
    	world_map.pop(world_map.index(''))
    return (world_map)

def determine_connection(active_letters, letters_on_board):
	#This works sometimes. Other times it returns False when it should not. Why is this? Oh, it's not detecting any direction. That's why
	#Solution - Use 4 for loops while working to make sure the key letters don't evade detection
	#Check the Four squares around the board_letter
	#Still evading detection
	confirmed_letters = []
	detect_bot = active_letters[0].rect.copy()
	starting_letter = active_letters[0]
	letter_chain = False
	direction = "Unkown"
	#Determine if any chain exists and what direction that chain is in
	detect_bot = detect_bot.move(BLOCK_LENGTH, 0)
	for board_letter in letters_on_board:
		if(detect_bot.collidepoint(board_letter.rect.center)):
			letter_chain = True
	detect_bot = detect_bot.move(-BLOCK_LENGTH*2, 0)
	for board_letter in letters_on_board:
		if(detect_bot.collidepoint(board_letter.rect.center)):
			letter_chain = True
	#Make sure the movement is in a little plus symbol
	detect_bot = detect_bot.move(BLOCK_LENGTH, BLOCK_LENGTH)
	for board_letter in letters_on_board:
		if(detect_bot.collidepoint(board_letter.rect.center)):
			letter_chain = True
	detect_bot = detect_bot.move(0, -BLOCK_LENGTH*2)
	for board_letter in letters_on_board:
		if(detect_bot.collidepoint(board_letter.rect.center)):
			letter_chain = True
	for letter in active_letters:
		if (letter.pos_x == starting_letter.pos_x):
			direction = "Vertical"
		elif (letter.pos_y == starting_letter.pos_y):
			direction = "Horizontal"
	#Once the Letter Chain Boolean has been set to True you can check if all of the active_letters exist in that chain
	if(letter_chain == True):
		#Find Starting Letter based on direction
		finding_starting_letter = True
		starting_letter = active_letters[0]
		search_multiplier = 0
		letter_found = False
		while(finding_starting_letter):
			letter_found = False
			detect_bot = active_letters[0].rect.copy()
			if(direction == "Horizontal"):
				detect_bot = detect_bot.move(-BLOCK_LENGTH*search_multiplier, 0)
				for board_letter in letters_on_board:
					if(detect_bot.collidepoint(board_letter.rect.center)):
						search_multiplier = search_multiplier + 1
						#print("Search Multiplier Increased to", str(search_multiplier))
						letter_found = True
						starting_letter = board_letter
			elif(direction == "Vertical"):
				detect_bot = detect_bot.move(0, -BLOCK_LENGTH*search_multiplier)
				for board_letter in letters_on_board:
					if(detect_bot.collidepoint(board_letter.rect.center)):
						search_multiplier = search_multiplier + 1
						#print("Search Multiplier Increased to", str(search_multiplier))
						letter_found = True
						starting_letter = board_letter
			if(letter_found == False):
				finding_starting_letter = False
		#Once the starting letter has been found, move along and confirm that all the active_letters are in a line
		#Trouble confirming all letters - Letters being bonfirmed multiple times
		confirming_connection = True
		word_length = 0
		reading_word = False
		while(confirming_connection):
			reading_word = False
			detect_bot = starting_letter.rect.copy()
			if(direction == "Horizontal"):
				detect_bot = detect_bot.move(BLOCK_LENGTH*word_length, 0)
				for board_letter in letters_on_board:
					if(detect_bot.collidepoint(board_letter.rect.center)):
						word_length = word_length + 1
						confirmed_letters.append(board_letter)
						reading_word = True
				if(reading_word == False):
					confirming_connection = False
			elif(direction == "Vertical"):
				detect_bot = detect_bot.move(0, BLOCK_LENGTH*word_length)
				for board_letter in letters_on_board:
					if(detect_bot.collidepoint(board_letter.rect.center)):
						confirmed_letters.append(board_letter)
						word_length = word_length + 1
						reading_word = True
				if(reading_word == False):
					confirming_connection = False
		if(len(confirmed_letters) >= len(active_letters)):
			return True
		else:
			return False




def detect_active_words(active_letters, letters_on_board):
	#Examines the active letters. Returns False if the letters are not all in one line.
	#Returns True with every word that the active letters form
	if(len(active_letters) == 0):
		return False
	x_location = active_letters[0].pos_x
	y_location = active_letters[0].pos_y
	for letter in active_letters:
		if(letter.pos_x != x_location and letter.pos_y != y_location):
			return False
			
	#Detect if all the active letters are connected in a line
	if (determine_connection(active_letters, letters_on_board) == True):
		return True
	else:
		return False
		

def find_words(active_letters, letters_on_board):
	reporting_word = True
	starting_letter = active_letters[0]
	consecutive_letter = False
	played_word = "Not Working"
	direction = "Unknown"
	confirm_play = False
	word_report = []
	one_letter = False
	play_value = 0
	word_multiplier = 1
	letter_value = 0
	global turn_score
	global DW, TW, TL, DL
	#Connection needs to be determined here. Otherwise false words are getting reported.
	#Use the Find Starting Letter loop used in the determine connection function
	#Find Start of Horizontal Words
	for letter in letters_on_board:
		if(letter.pos_y == active_letters[0].pos_y):
			if(letter.pos_x <= starting_letter.pos_x):
				confirm_play = True
		else:
			for letter in active_letters:
				if(letter.pos_y != active_letters[0].pos_y):
					confirm_play = False
	#Check the Boolean after the For Loop to really Confirm Direction of Play
	if(confirm_play == True):
		direction = "Horizontal"
	#Find Start of Vertical Words
	if(direction == "Unknown"):
		for letter in letters_on_board:
			if(letter.pos_x == active_letters[0].pos_x):
				if(letter.pos_y <= starting_letter.pos_y):
					confirm_play = True
			else:
				for letter in active_letters:
					if(letter.pos_x != active_letters[0].pos_x):
						confirm_play = False
		if(confirm_play == True):
			direction = "Vertical"
	finding_starting_letter = True
	search_multiplier = 0
	#Find the Starting Letter
	while(finding_starting_letter):
		letter_found = False
		detect_bot = active_letters[0].rect.copy()
		if(direction == "Horizontal"):
			detect_bot = detect_bot.move(-BLOCK_LENGTH*search_multiplier, 0)
			for board_letter in letters_on_board:
				if(detect_bot.collidepoint(board_letter.rect.center)):
					search_multiplier = search_multiplier + 1
					#print("Search Multiplier Increased to", str(search_multiplier))
					letter_found = True
					starting_letter = board_letter
		elif(direction == "Vertical"):
			detect_bot = detect_bot.move(0, -BLOCK_LENGTH*search_multiplier)
			for board_letter in letters_on_board:
				if(detect_bot.collidepoint(board_letter.rect.center)):
					search_multiplier = search_multiplier + 1
					#print("Search Multiplier Increased to", str(search_multiplier))
					letter_found = True
					starting_letter = board_letter
		if(letter_found == False):
				finding_starting_letter = False
	#Report the Word
	played_word = starting_letter.letter
	if(starting_letter.coordinates in DW and starting_letter in active_letters):
		word_multiplier += 1
	if(starting_letter.coordinates in TW and starting_letter in active_letters):
		word_multiplier += 2
	letter_value = starting_letter.point_value
	if(starting_letter.coordinates in DL and starting_letter in active_letters):
		letter_value = letter_value * 2
	if(starting_letter.coordinates in TL and starting_letter in active_letters):
		letter_value = letter_value * 3
	play_value += letter_value
	#print(letter_value, "points for", starting_letter.letter)
	scouter = starting_letter.rect.copy()
	#Report the Word - ReWRITE
	while(reporting_word):
		letter_value = 0
		if(direction == "Horizontal"):
			consecutive_letter = False
			#It must not be moving
			scouter = scouter.move(BLOCK_LENGTH, 0)
			for letter in letters_on_board:
				if(scouter.collidepoint(letter.rect.center)):
					played_word += letter.letter
					if(letter.coordinates in DW and letter in active_letters):
						word_multiplier += 1
					if(letter.coordinates in TW and letter in active_letters):
						word_multiplier += 2
					letter_value = letter.point_value
					if(letter.coordinates in DL and letter in active_letters):
						letter_value = letter_value * 2
					if(letter.coordinates in TL and letter in active_letters):
						letter_value = letter_value * 3
					play_value += letter_value
					#print(letter_value, "points for", letter.letter)
					consecutive_letter = True
			if(consecutive_letter == False):
				reporting_word = False
		elif(direction == "Vertical"):
			consecutive_letter = False
			scouter = scouter.move(0, BLOCK_LENGTH)
			for letter in letters_on_board:
				if(scouter.collidepoint(letter.rect.center)):
					played_word += letter.letter
					if(letter.coordinates in DW and letter in active_letters):
						word_multiplier += 1
					if(letter.coordinates in TW and letter in active_letters):
						word_multiplier += 2
					letter_value = letter.point_value
					if(letter.coordinates in DL and letter in active_letters):
						letter_value = letter_value * 2
					if(letter.coordinates in TL and letter in active_letters):
						letter_value = letter_value * 3
					play_value += letter_value
					#print(letter_value, "points for", letter.letter)
					consecutive_letter = True
			if(consecutive_letter == False):
				reporting_word = False
		else:
			reporting_word = False
	if(len(played_word) > 1):
		word_report.append(played_word)
		turn_score += (play_value * word_multiplier)
		#if(word_multiplier > 1):
			#print("Word multiplied by", word_multiplier)
		#print("Total of", (play_value*word_multiplier), "points")
		if(len(active_letters) == 7):
			turn_score += 50
			#print("BINGO")
	#Find Bonus Words
	potential_bonus_words = []
	bonus_word_number = 0
	finding_bonus_word_start = False
	reading_bonus_word = False
	bonus_search_multiplier = 0
	consecutive_bonus_letter = False
	bonus_letter_found = False
	bonus_word_length = 0
	bonus_word = ""
	#All the bonus words will be Horizontal if the main word is Vertical and vice versa
	if(direction == "Vertical"):
		for letter in active_letters:
			play_value = 0
			word_multiplier = 1
			bonus_scouter = letter.rect.copy()
			bonus_scouter = bonus_scouter.move(BLOCK_LENGTH, 0)
			for board_letter in letters_on_board:
				if(bonus_scouter.collidepoint(board_letter.rect.center)):
					finding_bonus_word_start = True
					#print("Found a", board_letter.letter)
			bonus_scouter = bonus_scouter.move(-BLOCK_LENGTH*2, 0)
			for board_letter in letters_on_board:
				if(bonus_scouter.collidepoint(board_letter.rect.center)):
					finding_bonus_word_start = True
					#print("Found a", board_letter.letter)
			#Maybe I should recenter the bonus_scouter
			bonus_scouter = bonus_scouter.move(BLOCK_LENGTH, 0)
			while(finding_bonus_word_start == True):
				bonus_letter_found = False
				bonus_scouter = letter.rect.copy()
				bonus_scouter = bonus_scouter.move((-BLOCK_LENGTH*bonus_search_multiplier), 0)
				for bonus_starter in letters_on_board:
					if(bonus_scouter.collidepoint(bonus_starter.rect.center)):
						bonus_search_multiplier = bonus_search_multiplier + 1
						#print("Bonus Search Multiplier Increased to", str(bonus_search_multiplier))
						bonus_letter_found = True
						bonus_word_start = bonus_starter
						#print("I think that the Bonus word begins with the letter", bonus_starter.letter)
				if(bonus_letter_found == False):
					finding_bonus_word_start = False
					reading_bonus_word = True
					bonus_search_multiplier = 0
			while(reading_bonus_word == True):
				consecutive_bonus_letter = False
				bonus_scouter = bonus_word_start.rect.copy()
				bonus_scouter = bonus_scouter.move(BLOCK_LENGTH*bonus_word_length, 0)
				for board_letter in letters_on_board:
					if(bonus_scouter.collidepoint(board_letter.rect.center)):
						bonus_word += board_letter.letter
						if(board_letter.coordinates in DW and board_letter in active_letters):
							word_multiplier += 1
						if(board_letter.coordinates in TW and board_letter in active_letters):
							word_multiplier += 2
						letter_value = board_letter.point_value
						if(board_letter.coordinates in DL and board_letter in active_letters):
							letter_value = letter_value * 2
						if(board_letter.coordinates in TL and board_letter in active_letters):
							letter_value = letter_value * 3
						play_value += letter_value
						#print(letter_value, "points for", board_letter.letter)
						#print("Confirming", board_letter.letter)
						bonus_word_length = bonus_word_length + 1
						consecutive_bonus_letter = True
				if(consecutive_bonus_letter == False):
					reading_bonus_word = False
					bonus_word_length = 0
			if(bonus_word != ''):
				word_report.append(bonus_word)
				turn_score += (play_value * word_multiplier)
				#if(word_multiplier > 1):
					#print("Word Multiplied by", word_multiplier)
				#print("Total of", (play_value*word_multiplier), "points")
			bonus_word = ""
	elif(direction == "Horizontal"):
		for letter in active_letters:
			play_value = 0
			word_multiplier = 1
			bonus_scouter = letter.rect.copy()
			bonus_scouter = bonus_scouter.move(0, BLOCK_LENGTH)
			for board_letter in letters_on_board:
				if(bonus_scouter.collidepoint(board_letter.rect.center)):
					finding_bonus_word_start = True
					#print("Hunting the letter", board_letter.letter)
			bonus_scouter = bonus_scouter.move(0, -BLOCK_LENGTH*2)
			for board_letter in letters_on_board:
				if(bonus_scouter.collidepoint(board_letter.rect.center)):
					finding_bonus_word_start = True
					#print("Hunting the letter", board_letter.letter)
			#Maybe I should recenter the bonus_scouter; This will allow it to find the proper start.
			bonus_scouter = bonus_scouter.move(0,BLOCK_LENGTH)
			while(finding_bonus_word_start == True):
				bonus_letter_found = False
				bonus_scouter = letter.rect.copy()
				bonus_scouter = bonus_scouter.move(0, (-BLOCK_LENGTH*bonus_search_multiplier))
				for bonus_starter in letters_on_board:
					if(bonus_scouter.collidepoint(bonus_starter.rect.center)):
						bonus_search_multiplier = bonus_search_multiplier + 1
						#print("Bonus Search Multiplier Increased to", str(bonus_search_multiplier))
						bonus_letter_found = True
						bonus_word_start = bonus_starter
						#print("I think that the Bonus word begins with the letter", bonus_starter.letter)
				if(bonus_letter_found == False):
					finding_bonus_word_start = False
					reading_bonus_word = True
					bonus_search_multiplier = 0
			while(reading_bonus_word == True):
				consecutive_bonus_letter = False
				bonus_scouter = bonus_word_start.rect.copy()
				bonus_scouter = bonus_scouter.move(0, BLOCK_LENGTH*bonus_word_length)
				for board_letter in letters_on_board:
					if(bonus_scouter.collidepoint(board_letter.rect.center)):
						bonus_word += board_letter.letter
						if(board_letter.coordinates in DW and board_letter in active_letters):
							word_multiplier += 1
						if(board_letter.coordinates in TW and board_letter in active_letters):
							word_multiplier += 2
						letter_value = board_letter.point_value
						if(board_letter.coordinates in DL and board_letter in active_letters):
							letter_value = letter_value * 2
						if(board_letter.coordinates in TL and board_letter in active_letters):
							letter_value = letter_value * 3
						play_value += letter_value
						#print(letter_value, "points for", letter.letter)
						#print("Confirming", board_letter.letter)
						bonus_word_length = bonus_word_length + 1
						consecutive_bonus_letter = True
				if(consecutive_bonus_letter == False):
					reading_bonus_word = False
					bonus_word_length = 0
			if(bonus_word != ''):
				word_report.append(bonus_word)
				turn_score += (play_value * word_multiplier)
				#if(word_multiplier > 1):
					#print("Word Multiplied by", word_multiplier)
				#print("Total of", (play_value*word_multiplier), "points")
			bonus_word = ""
	return word_report
	

def reset_rack(letter_rack):
	random.shuffle(letter_rack)
	for x in range(len(letter_rack)):
		letter_rack[x].rect.center = (700 + 49*x, 621)
		if(letter_rack[x].original_letter == '?'):
			letter_rack[x].letter = '?'

def draw_letter(bag):
    draw = random.randint(0, len(bag) - 1)
    deal = bag[draw]
    #Remove the card from the deck once it's been dealt
    bag.pop(draw)
    return deal

def create_letter(letter, x, y):
	if(letter == 'A'):
		creation = Letter(x,y, 'A', 1, "Scrabble Letter - A.png")
	elif(letter == 'B'):
		creation = Letter(x,y, 'B', 3, "Scrabble Letter - B.png")
	elif(letter == 'C'):
		creation = Letter(x,y, 'C', 3, "Scrabble Letter - C.png")
	elif(letter == 'D'):
		creation = Letter(x,y, 'D', 2, "Scrabble Letter - D.png")
	elif(letter == 'E'):
		creation = Letter(x,y, 'E', 1, "Scrabble Letter - E.png")
	elif(letter == 'F'):
		creation = Letter(x,y, 'F', 4, "Scrabble Letter - F.png")
	elif(letter == 'G'):
		creation = Letter(x,y, 'G', 2, "Scrabble Letter - G.png")
	elif(letter == 'H'):
		creation = Letter(x,y, 'H', 4, "Scrabble Letter - H.png")
	elif(letter == 'I'):
		creation = Letter(x,y, 'I', 1, "Scrabble Letter - I.png")
	elif(letter == 'J'):
		creation = Letter(x,y, 'J', 8, "Scrabble Letter - J.png")
	elif(letter == 'K'):
		creation = Letter(x,y, 'K', 5, "Scrabble Letter - K.png")
	elif(letter == 'L'):
		creation = Letter(x,y, 'L', 1, "Scrabble Letter - L.png")
	elif(letter == 'M'):
		creation = Letter(x,y, 'M', 3, "Scrabble Letter - M.png")
	elif(letter == 'N'):
		creation = Letter(x,y, 'N', 1, "Scrabble Letter - N.png")
	elif(letter == 'O'):
		creation = Letter(x,y, 'O', 1, "Scrabble Letter - O.png")
	elif(letter == 'P'):
		creation = Letter(x,y, 'P', 3, "Scrabble Letter - P.png")
	elif(letter == 'Q'):
		creation = Letter(x,y, 'Q', 10, "Scrabble Letter - Q.png")
	elif(letter == 'R'):
		creation = Letter(x,y, 'R', 1, "Scrabble Letter - R.png")
	elif(letter == 'S'):
		creation = Letter(x,y, 'S', 1, "Scrabble Letter - S.png")
	elif(letter == 'T'):
		creation = Letter(x,y, 'T', 1, "Scrabble Letter - T.png")
	elif(letter == 'U'):
		creation = Letter(x,y, 'U', 1, "Scrabble Letter - U.png")
	elif(letter == 'V'):
		creation = Letter(x,y, 'V', 4, "Scrabble Letter - V.png")
	elif(letter == 'W'):
		creation = Letter(x,y, 'W', 4, "Scrabble Letter - W.png")
	elif(letter == 'X'):
		creation = Letter(x,y, 'X', 8, "Scrabble Letter - X.png")
	elif(letter == 'Y'):
		creation = Letter(x,y, 'Y', 4, "Scrabble Letter - Y.png")
	elif(letter == 'Z'):
		creation = Letter(x,y, 'Z', 10, "Scrabble Letter - Z.png")
	else:
		creation = Letter(x,y, '?', 0, "Scrabble Letter - Blank.png")
	return creation
	#Creates a letter object based upon what was drawn
	#Also need this to snap to the rack
	#This function needs another parameter to represent where on the letter rack it'll spawn

def find_in_dictionary(dictionary, word_report):
	checklist = []
	for x in word_report:
		for word in dictionary:
			if (x == word):
				checklist.append(x)
	if (len(checklist) == len(word_report)):
		return True
	else:
		return False


def main():
	run = True
	global turn_score
	global player_score 
	global player_two_score
	global player_one_name, player_two_name
	introduction_phase = True
	game_over_phase = False
	current_turn = 0
	blank_buttons = create_blank_buttons()
	game_board = read_map(MAPFILE)
	dictionary = read_map(DICTIONARY)
	letter_bag = read_bag(LETTERBAG)
	indicator = Indicator(120, 170, "Indicator.png")
	play_button = Button(GREY, 700, 180, 150, 60, "PLAY")
	reset_button = Button(GREY, 700, 270, 150, 60, "RESET")
	exchange_button = Button(GREY, 700, 510, 300, 60, "EXCHANGE")
	pass_button = Button(GREY, 700, 360, 150, 60, "PASS")
	game_buttons = [play_button, reset_button, exchange_button, pass_button]
	confirm_button = Button(GREY, 280, 535, 300, 60, "CONFIRM")
	delete_button = Button(GREY, 650, 535, 250, 60, "DEL")
	finish_button = Button(GREY, 700, 356, 250, 60, "FINISH")
	reveal_button = Button(GOLD, 670, 582, 360, 60, "REVEAL")
	random.shuffle(letter_bag)
	player_one_letter_rack = []
	player_two_letter_rack = []
	letter_rack = player_one_letter_rack
	letter_rack_group = pygame.sprite.Group()
	letter_group = pygame.sprite.Group()
	active_letters = []
	active_words = []
	letters_on_board = []
	letter_in_hand_bool = False
	letter_in_hand = 0
	exchanging = False
	exchange_letters = []
	using_blank = False
	used_starting_square = False
	new_turn = True
	name_entry = 0
	display_blank = False
	blank_pressed = 0
	winner = "NOBODY"
	end_game_points = 0
	show_reveal = True
	reveal_pressed = 0
	use_reveal = True
	#We want to draw 7 random letters from the bag of 100 letters.
	for x in range(7):
		new_letter = draw_letter(letter_bag)
		new_letter_object = create_letter(new_letter, (700 + (49*x)), 621)
		player_one_letter_rack.append(new_letter_object)
	for x in range(7):
		new_letter = draw_letter(letter_bag)
		new_letter_object = create_letter(new_letter, (700 + (49*x)), 621)
		player_two_letter_rack.append(new_letter_object)
	coordinates = get_coordinates(game_board)
	clock = pygame.time.Clock()
	#Active Blank will be properly assigned later.
	active_blank = letter_rack[0]

	while(introduction_phase == True):
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				introduction_phase = False
				#run = False
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				for button in blank_buttons:
					if(button.rect.collidepoint(pygame.mouse.get_pos())):
						if(name_entry == 0):
							if(len(player_one_name) < 13):
								player_one_name += button.text
						elif(name_entry == 1):
							if(len(player_two_name) < 13):
								player_two_name += button.text
				if (confirm_button.rect.collidepoint(pygame.mouse.get_pos())):
					if(name_entry == 0):
						name_entry += 1
						indicator.MoveTo(125,320)
					elif(name_entry == 1):
						indicator.MoveTo(125, 550)
						confirm_button.text = "START"
						name_entry += 1
					else:
						introduction_phase = False
				if (delete_button.rect.collidepoint(pygame.mouse.get_pos())):
					if(name_entry == 0):
						player_one_name = player_one_name[:-1]
					elif(name_entry == 1):
						player_two_name = player_two_name[:-1]
		clock.tick(60)
		redrawIntro(win, blank_buttons, confirm_button, delete_button, indicator, player_one_name, player_two_name)

	while(run):
		now = pygame.time.get_ticks()
		if(using_blank == True):
			blank_pressed = pygame.time.get_ticks()
		if(use_reveal == True):
			reveal_pressed = pygame.time.get_ticks()
		if(now - blank_pressed > 400 and display_blank == True):
			display_blank = False
		if(now - reveal_pressed > 400 and show_reveal == True):
			show_reveal = False
		if(new_turn == True):
			show_reveal = True
			use_reveal = True
			if(current_turn % 2 == 0):
				letter_rack = player_one_letter_rack
				indicator.MoveTo(670,90)
			elif(current_turn % 2 == 1):
				letter_rack = player_two_letter_rack
				indicator.MoveTo(670,140)
			letter_rack_group.empty()
			letter_group.empty()
			reset_rack(letter_rack)
			for letter in letter_rack:
				letter_rack_group.add(letter)
				letter_group.add(letter)
			for letter in letters_on_board:
				letter_group.add(letter)
			new_turn = False
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				run = False
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				for button in blank_buttons:
					if(using_blank == True):
						if(button.rect.collidepoint(pygame.mouse.get_pos())):
							active_blank.Assign_Blank(button.text)
							using_blank = False
							blank_pressed = pygame.time.get_ticks()
				if (reveal_button.rect.collidepoint(pygame.mouse.get_pos()) and display_blank == False):
					reveal_pressed = pygame.time.get_ticks()
					use_reveal = False
				if (pass_button.rect.collidepoint(pygame.mouse.get_pos()) and display_blank == False):
					reset_rack(letter_rack)
					for letter in active_letters:
						letters_on_board.remove(letter)
					active_letters = []
					letter_in_hand = 0
					letter_in_hand_bool = False
					active_letters = []
					current_turn += 1
					new_turn = True
				if (reset_button.rect.collidepoint(pygame.mouse.get_pos()) and display_blank == False):
					reset_rack(letter_rack)
					#It's important to reset the letters on board as well
					for letter in active_letters:
						letters_on_board.remove(letter)
					active_letters = []
					letter_in_hand = 0
					letter_in_hand_bool = False
				if (exchange_button.rect.collidepoint(pygame.mouse.get_pos())):
					if(exchanging == False):
						exchange_button.set_Color(GOLD)
						exchanging = True
					elif(exchanging == True and len(exchange_letters) > 0):
						exchange_button.set_Color(GREY)
						#Why does the new rack contain exchange letters?! If I exchange X Letters. X/2 Come back as exchange letters
						#Do the letters have memory?
						for letter in exchange_letters:
							if(letter.to_be_exchanged == True):
								letter.Default_Image()
								letter_bag.append(letter.original_letter)
								#This line is causing confusion because I am itterating through the letter rack.
								#Iterate through a new array called Exchange_Letters instead
								letter_rack.remove(letter)
								letter_group.remove(letter)
						random.shuffle(letter_bag)
						for x in range (7 - len(letter_rack)):
							#Draw new letters
							new_letter = draw_letter(letter_bag)
							new_letter_object = create_letter(new_letter, (700 + (49*x)), 621)
							letter_group.add(new_letter_object)
							letter_rack.append(new_letter_object)
						reset_rack(letter_rack)
						for letter in active_letters:
							letters_on_board.remove(letter)
						active_letters = []
						letter_in_hand = 0
						letter_in_hand_bool = False
						active_letters = []
						current_turn += 1
						new_turn = True
						#Remember to reset the Exchange Letters array to Nothing
						exchange_letters = []
						exchanging = False
					else:
						exchange_button.set_Color(GREY)
						exchanging = False
				if (play_button.rect.collidepoint(pygame.mouse.get_pos()) and display_blank == False):
					#We need a function to detect what letters have been placed and if they form a valid word or not.
					#Letters are not properly being removed from active_letters
					for letter in letters_on_board:
						if(letter.coordinates == (7,7)):
							used_starting_square = True
					if(used_starting_square == True):
						if(detect_active_words(active_letters, letters_on_board) == True):
							new_word = find_words(active_letters, letters_on_board)
							if(find_in_dictionary(dictionary, new_word) == True):
								if(current_turn % 2 == 0):
									player_score += turn_score
								elif(current_turn % 2 == 1):
									player_two_score += turn_score
								turn_score = 0
								for letter in active_letters:
									letter_rack.remove(letter)
									letter_group.add(letter)
								active_letters = []
								#Draw New Letters
								for x in range(7-(len(letter_rack))):
									if(len(letter_bag) != 0):
										new_letter = draw_letter(letter_bag)
										new_letter_object = create_letter(new_letter, (700 + (49*x)), 621)
										letter_group.add(new_letter_object)
										letter_rack.append(new_letter_object)
									else:
										break
								reset_rack(letter_rack)
								active_letters = []
								current_turn += 1
								new_turn = True
							else:
								turn_score = 0
						else:
							turn_score = 0
				if(letter_in_hand_bool == True):
					letter_in_hand.selected = False
					letter_in_hand_bool = False
					#Include a way for the user to express how they wish to use the BLANK letters.
					if (letter_in_hand.snap(coordinates, letters_on_board) == True):
						if(letter_in_hand.letter == '?'):
							using_blank = True
							display_blank = True
							active_blank = letter_in_hand
						if(letter_in_hand not in active_letters):
							active_letters.append(letter_in_hand)
							letters_on_board.append(letter_in_hand)
					else:
						active_letters.remove(letter_in_hand)
						letters_on_board.remove(letter_in_hand)
					letter_in_hand_bool = False
					letter_in_hand = 0
				else:
					for letter in letter_group:
						if (letter.get_rect().collidepoint(pygame.mouse.get_pos()) and letter_in_hand_bool == False and letter in letter_rack and show_reveal == False):
							if(exchanging == False):
								letter.selected = True
								letter_in_hand_bool = True
								letter_in_hand = letter
								#This may prevent an excess spill to active_letters
								if(letter not in active_letters):
									active_letters.append(letter_in_hand)
									letters_on_board.append(letter_in_hand)
								break
							elif(exchanging == True):
								if(letter.to_be_exchanged == False):
									letter.to_be_exchanged = True
									letter.Exchange()
									exchange_letters.append(letter)
								else:
									letter.to_be_exchanged = False
									letter.Default_Image()
									exchange_letters.remove(letter)
		if(len(letter_bag) == 0):
			if(len(player_one_letter_rack) == 0):
				game_over_phase = True
				run = False
				letter_group.empty()
				for letter in letters_on_board:
					letter_group.add(letter)
				for letter in player_two_letter_rack:
					end_game_points += letter.point_value
				player_score += end_game_points
				player_two_score -= end_game_points
			elif(len(player_two_letter_rack) == 0):
				game_over_phase = True
				run = False
				letter_group.empty()
				for letter in letters_on_board:
					letter_group.add(letter)
				for letter in player_two_letter_rack:
					end_game_points += letter.point_value
				player_score += end_game_points
				player_two_score -= end_game_points
			if(player_score > player_two_score):
				winner = player_one_name
			elif(player_two_score > player_score):
				winner = player_two_name
			elif(player_score == player_two_score):
				winner = "NOBODY"
		clock.tick(60)
		#Maybe change this so the buttons are global
		redrawWindow(win, letter_rack_group, letter_group, game_buttons, blank_buttons, display_blank, indicator, reveal_button, show_reveal, game_board)
	while(game_over_phase == True):
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				game_over_phase = False
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				if (finish_button.rect.collidepoint(pygame.mouse.get_pos())):
					game_over_phase = False
					pygame.quit()
					sys.exit()
		clock.tick(60)
		game_over_screen(win, letter_group, finish_button, end_game_points, winner, game_board)

main()